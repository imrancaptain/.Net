﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _Final123_Student_Cost_Management_Project_
{
    public partial class Admin_Forms : Form
    {
        public Admin_Forms()
        {
            InitializeComponent();
        }

        private void Admin_Forms_Load(object sender, EventArgs e)
        {

        }
    }
}
